## ---------------------------
##
## Script name: Functional Programming in R
##
## Purpose of script: Summer School for Women in Political Methodology 
##
## Author: 
##
## Date Created: 2025-07-20
##
## Instructor: Allison Koh
## Email: a.w.koh@bham.ac.uk
##
## ---------------------------


# load dependencies -------------------------------------------------------
library(tidyverse)
library(here) # for path management 
library(rlang) # for tidy evaluation 