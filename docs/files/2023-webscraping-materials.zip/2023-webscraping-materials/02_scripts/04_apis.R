## ---------------------------
#
#' @title   R script for Day 4 - APIs
#' @author Allison Koh
#' @date 2023-09-21
#' 
#' @description
#' Corresponds to the Day 4 slides 
#
## ---------------------------


# notes -------------------------------------------------------------------
#' Examples using the Dad Joke API

# load dependencies -------------------------------------------------------
library(httr) # main package for using APIs 
library(tidyr) # for handling nested lists

# random endpoint  --------------------------------------------------------
#' returns a randomly  sampled joke 

endpoint <- "https://icanhazdadjoke.com"

# we can make a GET-request to this endpoint
resp <- GET(url = endpoint)

print(resp) # <== this is a 'response' object

# parse response
content(resp, as = "parsed") 

# send request with specified response type: plain text
resp <- GET(
  url = endpoint, 
  config = add_headers(Accept = "text/plain")
)

# parse response 
content(resp, as = "parsed")

# send request with specified response type: JSON
resp <- GET(
  url = endpoint, 
  config = accept_json()
)

# parse response 
content(resp, as = "parsed")


# Example 2: Search endpoint ----------------------------------------------
#' Allows a keyword-based search for jokes 
#' endpoint: "/search" 

endpoint <- "https://icanhazdadjoke.com/search"

params <- list(
  term = "love",
  limit = 10,
  page = 1
)

# make a GET-request
resp <- GET(
  url = endpoint, 
  query = params, # <== !!!
  config = accept_json()
)

# parsed response object 
res <- content(resp, as = "parsed")
str(res, 1) # look at the structure of the response obj 

# results element contains the jokes data 
str(res$result)

# handling nested lists 
# see how the 'results' element is structured
str(res$results, 1) 

# rectangle nested lists
df <- tibble(value = res$results) # <== create data frame with one "list column" called 'value'
df

unnest_wider(df, value) # <== "unnest" list elements' contents to columns

# parsed response obj 
str(res, 1)

# in case of the previous request:
res$next_page > res$current_page