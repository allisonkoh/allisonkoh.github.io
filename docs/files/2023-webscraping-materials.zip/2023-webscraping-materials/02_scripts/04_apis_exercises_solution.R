# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #  
#
#' @title	 R script for solutions to "Collecting Web Data from APIs" exercises
#' @date   2022-09-15
#
# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #

# load packages ----

library(readr)
library(jsonlite)
library(stringr)
library(tidyr)
library(dplyr)
library(purrr)
library(lubridate)
library(ggplot2)

# Exercise 1: Collect Twitter data for German MPs ----
library(rtweet)

# a) authenticate

# define path to your "credentials" file
fp <- file.path(
  Sys.getenv("SECRETS_PATH"),
  "twitter_summer_school_teaching_app_secret.json" # <== insert name of secrets file created above
)

# read them
creds <- jsonlite::read_json(fp)

# authenticate
auth <- rtweet_app(bearer_token = creds$bearer_token)
auth_as(auth)

# b) read German MPs Twitter handles (i.e., account names) ----
# IMPORTANT: please re-download the file from ILIAS (I updated it on 2022-09-15 16:38:16)
fp <- file.path("data", "german_mps_twitter_handles.tsv")
# CAUTION: you might need to change the file path !!!
mps <- readr::read_tsv(fp)

# c) get user information ----
users <- lookup_users(users = mps$handle)

# when were they created?
ggplot2::qplot(users$created_at)

# in which year were the most accounts created?
years <- lubridate::year(users$created_at)
table(years)

# alternatively
users %>% 
  select(screen_name, created_at) %>% 
  mutate(year_created = lubridate::year(created_at)) %>% 
  count(year_created) %>% 
  arrange(desc(n))

# most common hashtags?

#  just eye ball the result
all_words <- unlist(strsplit(users$description, split = " "))
sort(table(all_words), decreasing = TRUE) %>% head(200)

# alternatively:
str_extract_all(users$description, "#[A-Za-z0-9_]+") %>% 
  unlist() %>% 
  table() %>% 
  sort(decreasing = TRUE) %>% 
  head()

# d) get most recent tweets for a selected user ----
tweets <- get_timeline(user = mps$handle[1])
nrow(tweets)

# drop ...
tweets <- filter(
  tweets,
  # ... retweets
  !retweeted, 
  # ... quotes
  is.na(quoted_status_id),
  # ... and replies
  is.na(in_reply_to_status_id)
)

#  extract hasthtags from "entities" (list-)column
tweets$entities %>% 
  map("hashtags") %>% 
  map("text") %>% 
  # tabulate them
  unlist() %>% 
  table() %>% 
  sort(decreasing = TRUE) %>% 
  head()
  

# e) how long would it take to get all accounts' followers? ---

# the correct function to get this data is get_followers
# The documentation of this function tells us
#  1. the endpoint is "followers/ids", so the rate limit is
rate_lim_followers <- rate_limit(resource_match = "followers/ids")
#  2. the maximum number of followers per account and request is
5000

# So here is how many requests you have to make per account
n_requests_per_account <- ceiling( users$followers_count/5000 ) 
# note: the `ceiling()` functions rounds real-valued numbers to the next biggest integer
#       we need to round up because for each user we need to make 
#        - 1 request if the user has ≤  5,000 followers 
#        - 2 request if the user has ≤ 10,000 followers
#        - ...

# here is how many requests do you need make in total (just summ )
n_request_in_total <- sum( n_requests_per_account )

# how many rate limit windows per hour?
n_rate_limits_per_hour <- 60/15

# hint: base your estimate on the rate limit (per 15 minutes) for getting follower's IDs 
rate_lim_followers$limit
(n_request_in_total/rate_lim_followers$limit)/n_rate_limits_per_hour # hours <== this is the answer


# note: here is how you would actually get them
# but DON'T RUN THIS, it will take very long to complete
# alternatively
followers_data <- list()
for (i in 1:length(accounts)) {
  followers_data[[ i ]] <- get_followers(
    user = mps$handle[i], 
    retryonratelimit = TRUE, # to be patient with the API
    n = Inf # to get all the followers 
  )
}

# Exercise 2: Dad Jokes API ----

library(httr)

# 1. get all jokes that contain the term 'you'! ----

endpoint <- "https://icanhazdadjoke.com/search"

# define the search term
search_term <- "you"

# create empty list to collect the jokes data
jokes <- list()
# start with first page (default)
page_nr <- 1L 

# iterate
repeat {
  
  params <- list(term = search_term, page = page_nr)
  
  # make a GET-request
  resp <- GET(
    url = endpoint, 
    query = params, 
    config = accept_json()
  )
  
  # parse it 
  res <- content(resp, as = "parsed")
  
  jokes[[ page_nr ]] <- purrr::map_chr(res$results, "joke")
  # # alternatively:
  # jokes[[ page_nr ]] <- sapply(res$results, function(x) x$joke)
  
  # check stopping condition
  if (res$current_page == res$next_page)
    break
  
  # pause
  Sys.sleep(1)
  
  # increment the page counter
  page_nr <- page_nr + 1L
  message("\b\r", page_nr)
}

# unlist (to convert list of vectors) into a singl, long vector
unlist(jokes)

# 2. get all jokes ----

endpoint <- "https://icanhazdadjoke.com/search"

# we just use an empty search string to
search_term <- ""

# create empty list to collect the jokes data
jokes <- list()
# start with first page (default)
page_nr <- 1L 

# iterate
# CAUTION: This will take some time!
repeat {
  
  params <- list(term = search_term, page = page_nr)
  
  # make a GET-request
  resp <- GET(
    url = endpoint, 
    query = params, 
    config = accept_json()
  )
  
  # parse it 
  res <- content(resp, as = "parsed")
  
  jokes[[ page_nr ]] <- purrr::map_chr(res$results, "joke")
  
  # check stopping condition
  if (res$current_page == res$next_page)
    break
  
  # pause
  Sys.sleep(1)
  
  # increment the page counter
  page_nr <- page_nr + 1L
  message("\b\r", page_nr)
}

unlist(jokes)

# Exercise 3: Scrape articles published in the last 7 days containing the key word "Ukraine"   ----

# setup ----

# load your API key
api_key <- paste0(Sys.getenv("NYT_API_KEY"))

# a) Simple case: make  o n e  request ----

# define the query parameters
search_term <- "Elections"
params <- list(
  "q" = search_term, 
  "api-key" = api_key, 
  "page" = 1
  )

# make the get request
resp <- GET(
  url = "http://api.nytimes.com/svc/search/v2/articlesearch.json" # <== the endpoint
  , query = params
  , config = accept_json() # <== note that you want it back in JSON format
)

# parse the response
parsed <- content(resp, as = "parsed")

# inspect its structure
str(parsed, 2) # ==> we are interest primarily in the data in 'response' element

# extract relevant data:
# note: inspired by https://cran.r-project.org/web/packages/tidyr/vignettes/rectangle.html
# embed the 'docs' element of the parsed response in a (long) data frame
tibble(value = parsed$response$docs) %>% 
  # unnest indiviudal elements list elements into columns
  unnest_wider(value) %>% 
  # unnest the content in headline elements into columns
  unnest_wider(headline, names_sep = "_") %>% 
  # select relevant columns
  select(pub_date, headline_main, abstract, keywords) %>% 
  # optional: concatenate keywords (with semicolons)
  mutate(keywords = keywords %>% map_depth(2, "value") %>% map_chr(paste, collapse = ";"))

# but inspect the meta data ==> has important for "pagination"
parsed$response$meta

# b) Real application: make several requests to load all results ----

# wrap request logic in a function
make_request <- function(params) {
  resp <- GET(
    url = "http://api.nytimes.com/svc/search/v2/articlesearch.json"
    , query = params
    , config = accept_json()
  )
  stopifnot(resp$status_code == 200)
  
  # parse the JSON response
  parsed <- content(resp, as = "parsed")
  
  return(parsed$response)
}

# wrap code to extract relevant article information in a function
# (we can copy-paste the code from the lecture R script)
extract_article_information <- function(x) {
  tibble(value = x$docs) %>% 
    unnest_wider(value) %>% 
    unnest_wider(headline, names_sep = "_") %>% 
    select(pub_date, headline_main, abstract, keywords) %>% 
    mutate(keywords = keywords %>% map_depth(2, "value") %>% map_chr(paste, collapse = ";"))
}

# make requests an iterate over "pages" until all extracted
term <- "Election" 
begin_date <- "20230831" # format(today()-days(3), "%Y%m%d")
end_date <- "20230921" # format(today(), "%Y%m%d")

params <- list(
  "q" = term,
  "begin_date" = begin_date,
  "end_date" = end_date,
  "api-key" = api_key,
  "page" = 0 # we start at the first page
)

res <- list()
while (TRUE) {
  # make request
  resp <- make_request(params)
  message("\b\r", resp$meta$offset, "/", resp$meta$hits)
  
  # stopping condition: check if more results available
  if (resp$meta$offset < resp$meta$hits) {
    # if so, increment page counter
    params$page <- params$page + 1L
  } else {
    # otherwise, stop looping
    break
  }
  
  # extract information and add to output collector
  res[[length(res)+1L]] <- extract_article_information(resp)
  
  # pause (random time between 3 and 4 seconds)
  Sys.sleep(runif(1, 3, 4))
}

# combine row-wise
bind_rows(res)
