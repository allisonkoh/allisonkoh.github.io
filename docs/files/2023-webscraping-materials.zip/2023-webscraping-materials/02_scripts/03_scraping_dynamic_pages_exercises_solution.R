# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #  
#
#' @title	 R script for "Web scraping dynamic pages" exercises
#' @date   2022-09-14
#
# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #

# setup ----

library(RSelenium)
library(wdman)
library(purrr)

driver <- rsDriver(browser = "firefox", chromever = NULL, iedrver = NULL, phantomver = NULL) 
browser <- driver$client

# Exercise 1: Scrape the linkst to the most recent press releases of the German CDU/CSU ----

# navigate to page
url <- "https://www.cducsu.de/presse/pressemitteilungen"
browser$navigate(url)

# 1. scrape URLs of press releases (currently visible)

# a) get element containing all items
article_container <- browser$findElement(
  using = "css",
  value = ".shuffler.mark--press-press-release"
)

# this answer also works 
article_container <- browser$findElement(
  using = "css",
  value = ".masonry"
)


# b) get elements that represent links
article_links <- article_container$findChildElements(
  using = "css",
  value = ".game"
)

# c) get "href" attribute from links
article_urls <- map_chr(article_links, function(a) a$getElementAttribute("href")[[1]])
article_urls

# Exercise 2: Scraping automatic search term completions ----

url <- "https://duckduckgo.com/"

# navigate to page
browser$navigate(url)

# locate search bar
search_bar <- browser$findElement(
  using = "css selector", 
  value = "#searchbox_input"
)

# insert initial words
search_bar$sendKeysToElement(list("Mannheim is "))

# locate auto completions
auto_completions <- browser$findElements(
  using = "css", 
  value = "#listbox--searchbox_homepage > li"
  # # note: for you it's probably '.acp'
  # value = ".acp"
)

# extract their texts
sapply(auto_completions, function(el) el$getElementText()[[1]])

# Exercise 3: Scrape links to German MPs' pages ----

url <- "https://www.bundestag.de/abgeordnete"

browser$navigate(url)

# 1. locate and extract MP names and links first page 
link_elements <- browser$findElements(
  using = "css selector", 
  value = ".bt-slide-content a"
)

length(link_elements)
mp_links <- map_chr(link_elements, function(el) el$getElementAttribute("href")[[1]])
mp_names <- map_chr(link_elements, function(el) el$getElementAttribute("title")[[1]])

data.frame(name = mp_names, link = mp_links)

# 2. click on button to load more results
next_button <- browser$findElement("css selector", ".slick-next")
next_button$clickElement()

# 3. again, locate and extract MP names and links first page 

# note: now we would to repeat the same code as above
#  and again on the next page, and again ...
# Hence, we write a function that achieves this 

extract_mp_names_and_links <- function() {
  link_elements <- browser$findElements("css selector", ".bt-slide-content a")
  
  mp_names <- map_chr(link_elements, function(el) el$getElementAttribute("title")[[1]])
  mp_links <- map_chr(link_elements, function(el) el$getElementAttribute("href")[[1]])
  
  out <- data.frame(name = mp_names, link = mp_links)
  
  return(out)
}

# Now we could implement the iteration logic we used on Day 2
# The only remaining question is how to know when to stop iterating?
# In the exercise instructions, it says data for the first 100 MPs. 
# So we'll deal with this first.

# Let's call this Scenario 1:

# reload first page
browser$refresh()

# pause for the data to load
Sys.sleep(3)

# create an empty list to collect the results from each page
mp_links <- list()

# initialize the "page" counter
page_nr <- 1

repeat { 
  
  # a) get the MPs' data
  mp_links[[page_nr]] <- extract_mp_names_and_links()
  
  # b) check the stopping condition (100 or more rows); stop if it applies
  if ( sum(map_int(mp_links, nrow)) >= 100 ) {
    break
  }
  
  # otherwise, click the next button to trigger loading of more data ...
  next_button <- browser$findElement(
    using = "css selector",
    value = "button.slick-next.slick-arrow"
  )
  next_button$clickElement() 
  
  # increment the page counter
  page_nr <- page_nr + 1
  
  # ... and PAUSE! (to allow the website to load more data)
  Sys.sleep(2)
}

# inspect result
length(mp_links)
str(mp_links, 1)
# Wait, that's weird !!! 
# Why don't we always get 12 rows per iteration?
map_int(mp_links, nrow)

# Well, this example reminds us that on dynamic websites: "what you see is  NOT always what you get!"
# In this example, the data displayed before more data is loaded is still there.

# So what we can do is just click on the "next button" multiple times
#  and then scrape the MP names and links just once:
# note: This is only possible because the data displayed on the first "page"
#        is still available on the website (though not visible) after clicking
#        the next button. 
#       So when we scrape the MPs' names and links after having clicked the 
#        next button several times (and thus loaded more data several times),
#        we get the data for the currently visible MPs  a n d  the data for 
#        the MPs loaded previously that are currently not visible.

# reload first page
browser$refresh()

# pause for the data to load
Sys.sleep(3)

# # important: no empty list needed!
# mp_links <- list()

# # important: no page counter needed
# page_nr <- 1

repeat { 
  
  # a) get the MPs' data
  mps <- extract_mp_names_and_links() # <== not difference here
  
  # b) check the stopping condition (100 or more rows); stop if it applies
  if ( nrow(mps ) >= 100 ) { # <== not difference here
    break
  }
  
  # otherwise, click the next button to trigger loading of more data ...
  next_button <- browser$findElement(
    using = "css selector",
    value = "button.slick-next.slick-arrow"
  )
  next_button$clickElement() 
  
  # ... and PAUSE! (to allow the website to load more data)
  Sys.sleep(2)
}

# checl
nrow(mps) # alright


# Scenario 2: Load  a l l  data
# If you have carefully examined the page, you will realize that the 
#  "next button" is still displayed on the last results page.
# However, if it is not clickable anymore, its class name changes to
#  "slick-next slick-arrow slick-disabled". We can use this info to
#  decide when to stop

# reload first page
browser$refresh()

# pause for the data to load
Sys.sleep(3)

# initialize the "page" counter
page_nr <- 1

# create an empty data collector
mp_links <- list()

# because we now don't want to scrape all data, we set a limit
MAX_PAGES <- 5

# iterate
repeat {
  message("\b\r", "Page nr. ", page_nr)
  
  # extract MPs' names and links
  mps <- extract_mp_names_and_links()
  
  # locate next button
  next_button <- browser$findElement("css selector", ".slick-next")
  
  # check its class and stop if its "disabled" 
  button_class <- next_button$getElementAttribute("class")[[1]]
  if (button_class == "slick-next slick-arrow slick-disabled")
    break
  
  # also stop if MAX_PAGES is reached
  if (page_nr == MAX_PAGES)
    break
  
  # otherwise click 
  next_button$clickElement()
  
  # increment the page counter
  page_nr <- page_nr + 1
  
  # and pause
  Sys.sleep(4)
}

# IMPORTANT: because the data displayed before more data is loaded is still 
#  there on the next page, we can do is just click on the "next button" multiple 
#  times and then scrape the MP names and links just once:

# reload first page
browser$refresh()

# pause for the data to load
Sys.sleep(3)

# initialize the "page" counter
page_nr <- 1

# iterate
repeat {
  message("\b\r", "Page nr. ", page_nr)
  
  # locate next button
  next_button <- browser$findElement("css selector", ".slick-next")
  
  # check its class and stop if its "disabled" 
  button_class <- next_button$getElementAttribute("class")[[1]]
  if (button_class == "slick-next slick-arrow slick-disabled")
    break
  
  # also stop if MAX_PAGES is reached
  if (page_nr == MAX_PAGES)
    break
  
  # otherwise click 
  next_button$clickElement()
  
  # increment the page counter
  page_nr <- page_nr + 1
  
  # and pause
  Sys.sleep(2)
}

# extract MPs' names and links
mp_links <- extract_mp_names_and_links()

# how many MPs scraped?
nrow(mp_links)

# how many MPs scraped, really?
mp_links <- unique(mp_links)
nrow(mp_links)

# APPENDIX ----

# Scrape the most recent press releases of the German CDU/CSU ----
# navigate to page
url <- "https://www.cducsu.de/presse/pressemitteilungen"
browser$navigate(url)

# 1. scrape URLs of press releases (currently visible)

# a) get element containing all items
article_container <- browser$findElement(
  using = "css", 
  value = ".shuffler.mark--press-press-release"
)

# b) get elements that represent links 
article_links <- article_container$findChildElements(
  using = "css", 
  value = ".game"
)

length(article_links)
# c) get "href" attribute from links 
article_urls <- sapply(article_links, function(a) a$getElementAttribute("href")[[1]])

# 2. load more data
# a) locate "Mehr laden" button 
more_button <- browser$findElement(
  using = "css", 
  value = ".load-more__link"
)
# b) click on it
more_button$clickElement()

# 3. write a loop to repeat steps 1 and 2 until you've scraped the links to 100 articles

# a) define a function that exectutes step 1
scrape_article_urls <- function() {
  article_container <- browser$findElement(
    using = "css", 
    value = ".shuffler.mark--press-press-release"
  )
  article_links <- article_container$findChildElements(
    using = "css", 
    value = ".game"
  )
  article_urls <- sapply(article_links, function(a) a$getElementAttribute("href")[[1]])
  return(article_urls)
}

# test:
scrape_article_urls()

# b) define loop

repeat {
  article_urls <- scrape_article_urls()
  
  if (length(article_urls) >= 100)
    break
  
  message("scraped ", length(article_urls), " articles ...")
  
  # otherwise: load more ...
  browser$findElement("css", ".load-more__link")$clickElement()
  
  # and pause (a random number between 2 and 3 seconds) ...
  Sys.sleep(runif(1, 2, 3))
}

length(article_urls)

# 4. iterate over article links and scrape the relevant information (using `rvest`)
library(rvest)
library(dplyr)

# a) function to scrape data from an individual page

scrape_page <- function(url) {
  page <- read_html(url)
  
  date <- page %>% html_element(".meta__date") %>% html_text()
  
  title <- page %>% html_element(".head__headline") %>% html_text()
  
  abstract <- page %>% 
    html_elements(".head__content > p") %>% 
    html_text(trim = TRUE) %>% 
    paste(collapse = "\n")
  
  text_content <- page %>% 
    html_elements(".mantle__content p") %>% 
    html_text(trim = TRUE) %>% 
    paste(collapse = "\n")
  
  out <- tibble(
    title = title,
    date = date,
    abstract = abstract,
    text = text_content
  )
  
  return(out)
}

# b) iterate over URLs
press_releases <- list()

for (url in article_urls[1:5]) { # <== for testing purposes, we only iterate over first 5
  # scrape
  press_releases[[url]] <- scrape_page(url)
  
  # print status
  message("\b\r", length(press_releases),"/100")
  
  # and pause (a random number between 1 and 2 seconds) ...
  Sys.sleep(runif(1, 1, 2))
}

str(press_releases)

# bind list into data frame (row-wise)
press_releases_df <- dplyr::bind_rows(press_releases, .id = "url")
press_releases_df



# finally ----

browser$closeall()
server$stop()
