# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #  
#
#' @title	 R script for lecture "Web scraping dynamic pages"
#' @author Allison Koh & Hauke Licht
#' @date   2023-09-20
#
# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #

# setup ----

library(RSelenium)
library(wdman)
library(purrr)

# step 1: create a browser session ----

driver <- rsDriver(
  browser = "firefox", # <== use this browser
  # don't download other drivers!
  chromever = NULL, 
  iedrver = NULL,
  phantomver = NULL
) 
browser <- driver$client

# # ALTERNATIVE
# # note: we set a lot of arguments to NULL to avoid unnecessary downloads
# driver <- rsDriver(
#   port = as.integer(4444),
#   browser = "firefox", 
#   chromever = NULL, 
#   iedrver = NULL, 
#   phantomver = NULL
# ) 
# browser <- driver$client
# 
# # start the browser
# browser$open()

browser$browserName
browser$port

class(browser)
?remoteDriver

# step 2: navigate to a website ----
url <- "https://www.ru.nl/radboudsummerschool/courses/social-research-methods/"
browser$navigate(url)

# # alternatively: try 
# url <- "https://www.bundestag.de/abgeordnete"

browser$refresh()

browser$getCurrentUrl( ) # <== returns a list with one element

# getCurrentUrl(browser) # <== this does not work!

# step 3: finding elements ----

# get title of main content on SSSRM website
title <- browser$findElement(
  using = "css selector", 
  value = "h1.grid-title"
)
# note: the title object is an instance of the 'webElement' class
class(title)
?webElement

# this is how you can extract it's text (more on this later)
title$getElementText()  

# reload page:
browser$refresh()

# get anchor elements containing links that point to pages further information 
links <- browser$findElements(
  using = "css selector", 
  value = "a.siteLink"
)
class(links)
length(links)
str(links, 1)
class(links[[1]])
links[[1]]$getElementText()
links[[2]]$getElementText()

for (i in 1:length(links)) {
  print(links[[i]]$getElementText())
}

# # this 👇 does NOT work! 
# links$getElementText()

## step 3.1 find child elements ----

# find navigation items
navitems <- browser$findElements(
  using = "css selector", 
  value = "li.navitem"
)
class(navitems)
str(navitems, 1)

browser$navigate("https://quotes.toscrape.com/")
auhtor_links <- browser$findElements(
  using = "partial link text", 
  value = "/author/"
)
class(auhtor_links)
str(auhtor_links, 1)

# find anchor elements nested in navigation items 
navitems_links <- navitems[[2]]$findChildElements("css selector", "a")

# next step: extract information from 'navitems_links'
navitems_links[[1]]$getElementText()
# next step: extract information from 'navitems_links'
navitems_links[[1]]$getElementAttribute("href")



# step 4: Sending events ----

## (i) clicking ----

# go to list of MPs of the German parliament
url <- "https://www.bundestag.de/abgeordnete"
browser$navigate(url)

# find 'button' element representing next button
button <- browser$findElement(
  using = "css selector", 
  value = "button.slick-next"
) 

# click on it
button$clickElement()
# --> the content of your browser window has changed!

## (ii) inserting text ----

search_field <- browser$findElement(
  using = "css selector", 
  value = ".bab-filter-suchfeld"
)

# insert text
text <- list("Klose")
search_field$sendKeysToElement(text) 

# clear it again ("mark all" and then "delete")
search_field$sendKeysToElement(sendKeys = list(key = "command_meta", "a"))
# note: on Windows use "control" instead of "command_meta"

search_field$sendKeysToElement(sendKeys = list(key = "delete"))


## (iii) scrolling ----

browser$refresh()

# select body (2nd child of outer "html" tag)
body <- browser$findElement("css selector", "body")

# scroll down a little bit
body$sendKeysToElement(sendKeys = list(key = "page_down"))

# scroll to end of page
body$sendKeysToElement(list(key = "end"))

# alternatively: use JavaScript

# go to gesistraining account on Twitter
browser$navigate("https://twitter.com/gesistraining")

# note: just do the login manually

# scroll down to see older tweets
browser$executeScript("window.scrollTo(0, document.body.scrollHeight);")

# step 5: Extracting information ----

url <- "https://www.ru.nl/radboudsummerschool/courses/social-research-methods/"
browser$navigate(url)

# get title of main content on SSSRM website
element <- browser$findElement(using = "css selector", value = "h2")
element$getElementText()

# extract the entire HTML source code of the page
html_code <- browser$getPageSource()

# read it to convert it into an xml_document object we can manipulate with rvest functions
xml2::read_html(html_code[[1]])

# finally: close browser, stop server ----

browser$closeall()
driver$server$stop()
rm(driver)
