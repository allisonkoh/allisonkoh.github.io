# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #  
#
#' @title	 R script for slides "Advanced topis in web scraping with rvest"
#' @author Allison Koh & Hauke Licht
#' @date   2023-09-22
#
# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #

# setup ----

library(httr)
library(rvest)
library(dplyr)

# 1. create a session object ---

# example URL
url <- "https://scrapethissite.com/pages/simple/"

# create session object
sess <- session(url)
# note: when omitting the `config =  ...` bit works for you, leave it out

# inspect its class
class(sess)

# inspect its structure
str(sess, 1)

# look at the "response" element ==> its a {httr} 'response' object
sess$response

# use 'session' object like 'html_document' object ==> same, same
headings <- html_elements(sess, "h3")
length(headings)
html_text(headings, trim = TRUE) %>% head(3)

# 2. how to navigate with session objects ----
url <- "https://scrapethissite.com/pages/simple/"
sess <- session(url)

# move forward
new_url <- "https://www.scrapethissite.com/pages/forms"
sess <- session_jump_to(sess, new_url)

# back to first page
sess <- session_back(sess)

# inspect history
sess$url
sess$back
session_history(sess)

# 3. manipulate "user agent" info ----

# currently 
sess$response$request$options$useragent
# note: because I use `curl` (might be different on Windows)

# setting a new user agent
# ua <- "hello server!"
ua <- "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36"

# pass it when creating the session
sess <- session(
  url = url, 
  httr::user_agent(ua), # <== user agent info here
  config = httr::config(ssl_verifypeer = FALSE)
)

# check that this was successful
sess$config$options$useragent 


# 3. interacting with forms ----

# example site
url <- "https://scrapethissite.com/pages/forms/"

# create session
sess <- session(url)

# locate first form
form <- sess %>% 
  html_element("form") %>% 
  html_form()

# print
form

# insert a search query term
form_filled <- html_form_set(form, q = "New York")

# inspect
form_filled$fields$q$value

# submit your query to the form
sess <- session_submit(sess, form_filled)
# note: we overwrite old session object to "update" it after submitting the form

# look at table after: we only get results containing term New York 
sess %>% 
  html_element("table") %>% 
  html_table() %>% 
  pull(1) %>% 
  unique()


# 4. using forms to log in ----

# create session
url <- "https://www.stealmylogin.com/demo.html"
sess <- session(url)

# 1) locate the login form
login_form <- sess %>% html_element("form") %>% html_form()

# what fields and types ?
purrr::map_chr(login_form$fields, "type")

# 2) pass user info

# set values
login_form <- html_form_set(
  login_form, 
  # pass values to form fields
  "username" = "test.user@gmail.com", 
  "password" = "123456"
)

# check
purrr::map_chr(login_form$fields, "value")

# 3) submit 
sess <- session_submit(sess, login_form)

# was login successful?
httr::status_code(sess) # should be 200

# what info was posted?
URLdecode(rawToChar(sess$response$request$options$postfields))

# where have we been redirected?
sess$url

