## ---------------------------
#
#' @title	 R script for "Collecting Web Data from APIs" exercises
#' @author Allison Koh + Hauke Licht
#' @date 2023-09-16
#
## ---------------------------

# notes -------------------------------------------------------------------
#' Fill in the blanks anywhere you see a "TODO" or "..."

# load dependencies -------------------------------------------------------
library(httr)
library(tidyr)
library(dplyr)
library(purrr)

# load API keys and error handling ----------------------------------------

# store API keys (run commented line below in console)
# Sys.setenv(NYT_API_KEY = "IKlQAMIwOCNNE8KiShBHmnO3POFPp7nt") # new york times API
# Sys.setenv(NEWS_API_KEY = "XX") # news API

# retrieve keys
nyt_api_key <- Sys.getenv("NYT_API_KEY")
news_api_key <- Sys.getenv("NEWS_API_KEY")

# error handling for the NYT example 
if (nyt_api_key == ""){
  stop("Please set your NYT_API_KEY environment variable before running this script.")
}

# error handling for the News API example
if (news_api_key == ""){
  stop("Please set your NEWS_API_KEY environment variable before running this script.")
}

# Exercise 1: Dad Jokes API -----------------------------------------------

# 1. get all jokes that contain the term 'you'! ----

endpoint <- "https://icanhazdadjoke.com/search"

# define the search term
search_term <- "you"

# [ TODO: complete the `repeat` loop below to iterate over requests ]

# create empty list to collect the jokes data
jokes <- list()
# start with first page (default)
page_nr <- 1

# iterate
repeat {
  
  params <- list(
    term = search_term,
    page = page_nr
  )
  
  # make the GET-request
  resp <- GET(
    url = endpoint, 
    query = params, 
    config = accept_json()
  )
  
  # [ TODO: parse the response ]
  res <- content(resp, as = "parsed")
  
  # [ TODO: extract the jokes from the parsed response ]
  jokes[[ page_nr ]] <- sapply(res$results, function(x) x$joke)
  
  # [ TODO: check the stopping condition ]
  if ( res$current_page == res$total_pages ) {
    break
  }
  
  # pause
  Sys.sleep(1)
  
  # print current page number
  message(page_nr)
  
  # [ TODO: increment/increase the page counter ]
  page_nr <- page_nr + 1L
}

str(jokes, 1)
# convert the list of vectors of jokes into a single, long vector
jokes <- unlist(jokes)
is.character(jokes)
length(jokes)

# 2. get all jokes ----

endpoint <- "https://icanhazdadjoke.com/search"

# [ TODO: figure out an appropriate search term to retrive  a l l  jokes ]
search_term <- ...

# create empty list to collect the jokes data
jokes <- list()
# start with first page (default)
page_nr <- 1L 

# iterate
# CAUTION: This will take some time!
while (TRUE ) {
  
  # define the request parameters
  params <- list("term" = search_term, page = page_nr)
  
  # make a GET-request
  resp <- GET(
    url = endpoint, 
    query = params, 
    config = accept_json()
  )
  
  # [ TODO: parse the response ]
  res <- ...
  
  # [ TODO: extract the jokes from the parsed response ]
  jokes[[ page_nr ]] <- ...
  
  # [ TODO: check the stopping condition ]
  if ( ... )
    break
  
  # pause
  Sys.sleep(1)
  
  # increment the page counter
  page_nr <- page_nr + 1L
}

# combine all jokes
unlist(jokes)


# Exercise 2: Scrape NYT articles -----------------------------------------

# setup ----

endpoint <- "http://api.nytimes.com/svc/search/v2/articlesearch.json"
search_term <- "Elections"

# [ TODO: define the start and end date in 'YYYYmmdd' format ]
begin_date <- ...
end_date <- ...

# [ TODO: load or copy-paste your API key ]
api_key <- ...

# define the request parameters
params <- list(
  "q" = search_term,
  ... # [ TODO: add any missing request parameter(s) ]
)

# [ TODO: first make one request to check the format of the response object ]
resp <- GET(url = endpoint, query = params, config = accept_json())

# parse the JSON response
parsed <- content(resp, as = "parsed")

str(parsed$response, 1)

# hints: 
#  - inside the 'response' element, all article-related information is in the 'docs' element
#  - the 'docs' element is a list, too
str(parsed$response$docs, 1)
#  - each element of the 'docs' list represents an article
View(parsed$response$docs[[1]], 1)
#  - the relevant information is in the 'headline' and 'pub_date' fields

parsed$response$docs[[1]]$headline$main



i <- 1
headlines[[i]] <- parsed$response$docs[[i]]$headline$main


# [ TODO: figure out how to extract the publication date and headline text ]

headlines <- list()

for (i in 1:10){
  headlines[[i]] <- parsed$response$docs[[i]]$headline$main
}

# loopk for the number of documents 

for (i in 1:length(parsed$response$docs)){
  headlines[[i]] <- parsed$response$docs[[i]]$headline$main
}

# Exercise 3: News API ----------------------------------------------------

# load R package for the API
library(newsanchor)
library(lubridate) # relevant only if you have dates 

# [TODO: In the documentation, find information on how to find news outlets included in this package.]
View(...)

# [TODO: Look for different articles with that source] 
results <- get_headlines(sources = "...")

# [TODO: Scale up your data collection; collect articles from 5 news outlets.]

# [TODO: (if time) Look up information on news articles of personal interest.]



