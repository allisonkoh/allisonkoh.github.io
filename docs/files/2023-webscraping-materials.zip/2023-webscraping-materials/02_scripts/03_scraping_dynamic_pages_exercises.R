# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #  
#
#' @title	 R script for "Web scraping dynamic pages" exercises
#' @author Allison Koh & Hauke Licht
#' @date   2023-09-20
#
# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #

# notes -------------------------------------------------------------------
#' Complete the [TODO] tasks by filling in the blank ("...")

# setup ----

library(RSelenium)
library(wdman)
library(purrr)

driver <- rsDriver(browser = "firefox", chromever = NULL, iedrver = NULL, phantomver = NULL) 
browser <- driver$client

# Exercise 1: Scrape the most recent press releases of the German CDU/CSU ----

# navigate to page
url <- "https://www.cducsu.de/presse/pressemitteilungen"
browser$navigate(url)
# note: just manually close the pop-up window

# 1. scrape URLs of press releases (currently visible)

# a) get element containing all items
article_container <- browser$findElement(
  using = "css", 
  value = "..." # [ TODO: insert appropriate CSS selector ]
)
# note: there are many different valid CSS selectors to get a web element the nests the six 
#        press release web elements
class(article_container)

# is this actually the right element? check the text!
cat(article_container$getElementText()[[1]])

# b) get elements that represent links 
article_links <- # [ TODO: insert the appropriate RSelenium code ]
# hint: you need to search within the 'article_container' element
length(article_links)
class(article_links)
class(article_links[[1]])
article_links[[1]]$getElementText()
article_links[[1]]$getElementAttribute("href")[[1]]


# c) get "href" attribute from links 
article_urls <- sapply(
  article_links, 
  function(webelement) { 
    webelement$getElementAttribute("href")[[1]] 
  }
)


# Exercise 2: Scraping automatic search term completions ----

url <- "https://duckduckgo.com/"

# navigate to page
browser$navigate(url)

# locate search bar
search_bar <- browser$findElement(
  using = "css selector", 
  value = "" # [ TODO: insert CSS selector to locate the search bar ]
)

# insert initial words
search_string <- "Mannheim is" # [ TODO: insert a search string of your choice ]
search_bar$sendKeysToElement(list("q" = search_string))

# pause before extracting the auto completes
Sys.sleep(2)

# find all auto completion elements
auto_completions <- browser$findElements(
  using = "css selector",
  value =  "" # [ TODO: insert CSS selector to locate elements that represent autocompletion ]
)

class(auto_completions)
length(auto_completions) 
all( map_chr(auto_completions, class) == "webElement" )

str(auto_completions, 1)

# extract the text of auto completion text

## using a for loop
n_elements <- length(auto_completions)
for (i in 1:n_elements) {
  text <- auto_completions[[ i ]]$getElementText()[[1]]
  print(text)
}

# using list comprehension 
sapply(
  auto_completions, 
  function(el) el$getElementText()[[1]]
)

# # in rvest (static webscraping) it would be easier:
# page %>% 
#   html_elements("div.acp") %>% 
#   html_text()

# Exercise 3: Scrape links to German MPs' pages ----

url <- "https://www.bundestag.de/abgeordnete"

browser$navigate(url)

# 1. locate and extract MP names and links first page 

link_elements <- browser$findElements(
  using = "css selector", 
  value = ".bt-slide-content > a"# [ TODO: insert the appropriate CSS selector ]
)

length(link_elements)

mp_names <- sapply(link_elements, function(el) el$getElementAttribute("title")[[1]])
mp_links <- sapply(link_elements, function(el) el$getElementAttribute("href")[[1]])

# once the while loop has terminated: scrape links
data.frame(name = mp_names, link = mp_links)

# 2. locate and click on "next button" to load more results
next_button <- browser$findElement(
  using = "css selector",
  value = "button.slick-next.slick-arrow"# [ TODO: insert the appropriate CSS selector ]
)
next_button$clickElement() # [ TODO: use the clickElement() method to click on the button ]


# note: now we would to repeat the same code as above
# and again on the next page, and again ...
# Hence, we write a function that achieves this 

extract_mp_names_and_links <- function() {
  link_elements <- browser$findElements(
    using = "css selector", 
    value = ".bt-slide-content > a"# [ TODO: insert the appropriate CSS selector ]
  )
  
  mp_names <- sapply(link_elements, function(el) el$getElementAttribute("title")[[1]])
  mp_links <- sapply(link_elements, function(el) el$getElementAttribute("href")[[1]])
  
  # once the while loop has terminated: scrape links
  out <- data.frame(name = mp_names, link = mp_links)
  
  return(out)
}

extract_mp_names_and_links()
# 3. load more data
# 
# Now we could implement the iteration logic we used on Day 2
# The only remaining question is how to know when to stop iterating?
# If you have carefully examined the page, you will realize that the 
#  "next button" is still displayed on the last results page.
# However, if it is not clickable anymore, its class name changes to
#  "slick-next slick-arrow slick-disabled". We can use this info to
#  decide when to stop

# reload first page
browser$navigate(url)

# pause for the data to load
Sys.sleep(3)

# initialize the "page" counter
page_nr <- 1

# create an empty data collector
mp_links <- list()

# because we now don't want to scrape all data, we set a limit
MAX_PAGES <- 5

# iterate
while ( TRUE ) {
  message("\b\r", "Page nr. ", page_nr)
  
  # extract MPs' names and links
  mp_links[[ page_nr ]] <- # [ TODO: scrape the MP data from the current page ]
  
  # locate next button
  next_button <- browser$findElement("css selector", ".slick-next")
  
  # [ TODO: check if the button is enbaled and `break` if not ]
  # ...
  
  # also stop if MAX_PAGES is reached
  if (page_nr == MAX_PAGES)
    break
  
  # [ TODO: otherwise, click it ]
  # ...
  
  # increment the page counter
  page_nr <- page_nr + 1
  
  # and pause
  Sys.sleep(4)
}

# inspect result
length(mp_links)
str(mp_links, 1)
# CAUTION: do you notice something weird?

# Exercise 4: Scrape the press releases of the German CDU/CSU ----

# navigate to page
url <- "www.cducsu.de/presse/pressemitteilungen"
browser$navigate(url)

# 1. scrape URLs of press releases (currently visible)

# a) get element containing all items
article_container <- browser$findElement(
  using = "css", 
  value = # [ TODO: insert appropriate CSS selector ]
)
# b) get elements that represent links 
article_links <- article_container$findChildElements(
  using = "css", 
  value = # [ TODO: insert appropriate CSS selector ]
)
# c) get "href" attribute from links 
article_urls <- map_chr(article_links, function(a) a$getElementAttribute("href")[[1]])

# 2. load more data
# a) locate "Mehr laden" button 
more_button <- browser$findElement(
  using = "css", 
  value = # [ TODO: insert appropriate CSS selector ]
)
# b) click on it
# [TODO]

# 3. TODO: write a loop to repeat steps 1 and 2 until you've scraped the links to 100 articles
# 4. TODO: iterate over article links and scrape the relevant information (using `rvest`)

# finally ----

browser$closeall()
server$stop()
