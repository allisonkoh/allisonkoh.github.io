# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #  
#
#' @title	 R script for slides "Advanced topis in web scraping with RSelenium"
#' @author Allison Koh & Hauke Licht
#' @date   2023-09-22
#
# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #

# setup ----
library(RSelenium)

# 1) changing the user agent ----

ua <- "hello server!"
# ua <- "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"

ff_profile <- makeFirefoxProfile(list("general.useragent.override" = ua))

driver <- rsDriver(
  browser = "firefox", 
  chromever = NULL, 
  extraCapabilities = ff_profile
)

browser <- driver$client

url <- "https://www.whatismybrowser.com/detect/what-is-my-user-agent/"
browser$navigate(url)
# check you browser!

browser$closeall()
driver$server$stop()
rm(browser, driver)

# 2) changing the download directory ----

download_dir <- "/Users/hlicht/Downloads" # <== you need to change this on your computer

# see https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types
mime_types <- c(
  "text/csv",  
  "text/xml", #
  "application/json", 
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
)
mime_types <- paste(mime_types, collapse = ",")

ff_profile <- list(
  "browser.download.dir" = download_dir,
  "browser.download.folderList" = as.integer(2),
  "browser.download.manager.showWhenStarting" = FALSE,
  "browser.helperApps.neverAsk.saveToDisk" = mime_types
)
ff_profile <- makeFirefoxProfile(ff_profile)

driver <- rsDriver(
  browser = "firefox", 
  chromever = NULL, 
  extraCapabilities = ff_profile
)
browser <- driver$client

# example site
url <- "https://www.ourcommons.ca/Members/en/search?parliament=44&caucusId=all&province=all&gender=all&view=list"
browser$navigate(url)

Sys.sleep(4) # let the data load

dl_button <- browser$findElement("xpath", '//a[contains(text(), "CSV")]')
dl_button$clickElement()

browser$closeall()
driver$server$stop()
rm(browser, driver)

#  3) catching errors ----

# read more here: http://adv-r.had.co.nz/Exceptions-Debugging.html#condition-handling

# toy example
1+"a"

res <- tryCatch(1+2, error = function(err) err)
class(res)
inherits(res, "error")

res <- tryCatch(1+"a", error = function(err) err)

class(res)
inherits(res, "error")
res$message

# # can use as stopping condition
# if (inherits(res, "error"))
#   break

# real example
driver <- rsDriver(
  browser = "firefox", 
  chromever = NULL
)
browser <- driver$client
browser$navigate("https://duckduckgo.com/")

# problem: without catching the error, the loop breaks
for (i in 1:10) {
  print(i)
  print("start")
  browser$findElement("css", "xyz")
  print("end")
}
print("I'm done!")

# solution: catch the error!
for (i in 1:10) {
  print(i)
  print("start")
  
  # catch here
  element <- tryCatch(
    browser$findElement("css", "xyz"),
    error = function(x) x
  )
  if (inherits(element, "error"))
    break
  
  print("end")
}
print("I'm done!")

element <- tryCatch(
  browser$findElement("css", "xyz")
  , error = function(err) err
)
# note: still prints some warning messages (but this is  n o t  the ERROR message!)

inherits(element, "error")

element$message

# figure out what type of error it is by checking for keywords in error's message
grepl("NoSuchElement", element$message)


# if you want to use more code that might raise an error
res <- tryCatch(
  {
    1+2
    1+3
    # 1+"a"
    browser$findElement("css", "xyz")
  }
  , error = function(err) err
)

res$message

browser$closeall()
driver$server$stop()
rm(browser, driver)

# 4) headless browsing ----

extra_capabilities <- list("moz:firefoxOptions" = list(args = list('--headless')))

driver <- rsDriver(
  browser = "firefox", 
  chromever = NULL, 
  extraCapabilities = extra_capabilities
)
browser <- driver$client

browser$navigate("https://quotes.toscrape.com/")

browser$findElement("css", ".quote .text")$getElementText()

browser$screenshot(display = TRUE)

browser$closeall()
driver$server$stop()
rm(browser, driver)

# 5) user agend and headless browsing ----

ua <- "hello server!"
ff_profile <- makeFirefoxProfile(list("general.useragent.override" = ua))

extra_capabilities <- c(
  list("moz:firefoxOptions" = list(args = list('--headless')))
  , ff_profile
)

driver <- rsDriver(
  browser = "firefox", 
  chromever = NULL, 
  extraCapabilities = extra_capabilities
)
browser <- driver$client

url <- "https://www.whatismybrowser.com/detect/what-is-my-user-agent/"

browser$navigate(url)

browser$screenshot(display = TRUE)

browser$closeall()
driver$server$stop()
rm(browser, driver)
