# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #  
#
#' @title  Code for Day 2 of 3SRM course "Collecting Web Data with R" 
#' @author Hauke Licht
#' @date   2023-06-27
#
# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #

# load 'rvest' package
library(rvest)

# Basic rvest functions ----

# read_html() ----

# define URL
url <- "http://guardian.co.uk/"

# read+parse URL
page <- read_html(url)
# note: if this doesn't work, see: https://stackoverflow.com/a/63320626

# the returned object is a 'html_document'
page


# html_elements() ----

# extract level-3 headings
headings <- html_elements(page, css = "h3") # <== the last argument is the "CSS selector"

# return object is a 'xml_nodeset'
headings


# html_element() ----

# extract FIRST level-3 heading on page
heading <- html_element(page, css = "h3")

# return object is a 'xml_nodeset'
heading

# compare html_elements() to html_element()
length(headings) # multiple web elements/nodes
length(heading)  # just one web elements/nodes

# html_table() ----

# read+parse Premier League results
url <- "https://www.theguardian.com/football/premierleague/table"
page <- read_html(url)

# extract first table on page
tab <- html_element(page, "table")

# convert to data frame
html_table(tab)

# Using CSS selector ----

# use toy example website 
url <- "https://quotes.toscrape.com"

# read page's HTML source code into R
page <- read_html(url)

# Use case 1: extract text of all quotes
# Description: 
#  We want to get the text of all quotes (on the first page).
#  The web elements containing quotes are elements with 'span' tags and 
#   the class 'text'.
#  But to ensure that we only get the text of quotes, we first want 
#   to "drill down" to the elements representing quotes (tag: 'div', class: 'quote')
#   and only then extract the text from their child elements.
#
#  There are three styles in how you can achieve this, all implement 
#   the same logic:

# I. Base-R style:

# 1) get parent elements: 'div' elements with class 'quote'
parent_elements <- html_elements(page, css = "div.quote")
parent_elements

# 2) from parents get child elements: 'span' elements with class 'text'
text_elements <- html_elements(parent_elements, css = "span.text")
text_elements

# note: apply html_text() to extract quotes' texts
html_text(text_elements)

# II. Tidyverse ("piping") style:
page %>% 
  # 1) extract parents
  html_elements(css = "div.quote") %>% 
  # 2) extract children
  html_elements(css = "span.text") %>%
  # 3) extract text
  html_text()

# III. Using CSS syntax + piping:
page %>% 
  html_elements(css = "div.quote > span.text") %>% 
  html_text()

# Iterating over pages ----

# Usually, the data we are interested in is spread across multiple pages
# Hence we need to accomplish two tasks:
#  1. get the data from an individual page
#  2. repeat this for all pages

# In our example, we want to scrape the text of ALL quotes, their authors, and their tags
url <- "https://quotes.toscrape.com"
page <- read_html(url)

# Task 1: get the relevant data from a page

# a) get quote texts:
quote_texts <- page %>% 
  html_elements(".quote > .text") %>% 
  html_text()

# b) get quote authors:
quote_authors <- page %>% 
  html_elements(".quote") %>% 
  html_elements(".author") %>% 
  html_text()

# c) get quote tags:
quote_tags <- page %>% 
  html_elements("div.quote meta.keywords") %>% 
  html_attr("content") 

# creat data frame ("tibble")
out <- tibble(
  text = quote_texts, 
  author = quote_authors, 
  tags = quote_tags
)

# OR: combine all this in a custom function
# Note: the reason why we want to wrap the above code in a custom function is 
#  that the code used to iterate over pages will be more readable.

#' Function scrapes quotes' texts, authors and tags from an individual 
#'     page on quotes.toscrape.com 
#' 
#' @param x an 'html_document' object
#' @return a data frame with columns "text", "author", "tags" 
scrape_quotes <- function(page) {
  
  # get quote texts:
  quote_texts <- page %>% 
    html_elements(".quote > .text") %>% 
    html_text()
  
  # get quote authors:
  quote_authors <- page %>% 
    html_elements(".quote") %>% 
    html_elements(".author") %>% 
    html_text()
  
  # get quote tags:
  quote_tags <- page %>% 
    html_elements("div.quote meta.keywords") %>% 
    html_attr("content") 
  
  out <- tibble(
    text = quote_texts, 
    author = quote_authors, 
    tags = quote_tags
  )
  
  return(out)
}

# next, we also need a function to identify the link to the next page
# note: the call inside the function returns `NA` if the link cannot be found
find_link_to_next_page <- function(x) {
  x %>% 
    html_element("ul.pager > li.next > a") %>% 
    html_attr("href")
}

# Step 2: iterate over pages 
#
# Below, we use a `while` loop to iterate over pages.
# The reason we use a `while`, and not a `for` loop is that we 
#  do not (or might not) know in advance how many pages there are in total.
# Hence, we just go page by page until the "next page" link cannot be located.

# Note: below an example of the logic of a while loop

# We start with an intial value: cnt = 1
cnt <- 1
# Before each iteration, it is checked whether the 
#  expression in the parentheses -- here, "cnt < 10" -- is true.
# The loop stops proceding if not.
#
# So, the below code stops when cnt == 10 
while (cnt < 10) {
  print(cnt)
  cnt <- cnt + 1
}

# Now the real code

# define an empty list which we will use to "collect" the results of each iteration
quotes <- list()

# initialize a page counter
page_nr <- 1

# keep iterating "indefinitely" 
repeat {
  
  # In each iteration:
  
  # a) define URL of current page
  url <- paste0("https://quotes.toscrape.com/page/", page_nr)
  message(url)
  
  # b) read the page 
  page <- read_html(url)
  
  # c) scrape the quotes data
  tmp <- scrape_quotes(page)  
  # d) add current page Nr.
  tmp$page_nr <- page_nr
  # e) add the data to the output collector list
  quotes[[ page_nr ]] <- tmp
  
  # f) get link to next page (if exists) 
  next_pag_link <- find_link_to_next_page(page)
  
  # g) test if there is a next page link (THIS IS CRUCIAL !!!)
  if (is.na(next_pag_link)) {
    # if the link cannot be found (is `NA`), stop iterating
    break
  }
  
  # h) increment page counter
  page_nr <- page_nr + 1
  
  # i) pause
  Sys.sleep(1.5)
}

# finally: 

# a) validage
length(quotes)
str(quotes, 1)

# b) combine 
quotes <- dplyr::bind_rows(quotes)

nrow(quotes)
table(quotes$page_nr)

