# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #  
#
#' @title  Solutions for exercises on Day 2 of "Automated Web Data Collection with R" 
#' @author Allison Koh & Hauke Licht
#' @date   2023-09-19
#
# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #

# setup ----

library(httr)
library(rvest)
library(dplyr)
library(purrr)


# Using CSS selectors ----

url <- "https://quotes.toscrape.com/"
page <- read_html(url)

## locating quotes' texts ----

html_elements(page, ".text")

## locating quotes' authors ----

html_elements(page, ".author")

## locating the names of quotes' tags ----

html_elements(page, ".quote .tag")

## locating the links to quotes' authors' pages ----

# using sibling info
html_elements(page, ".author+a")

# using string-based search un href attribute value
html_elements(page, "a[href^='/author/']")
# see https://www.w3schools.com/cssref/css_selectors.php
# note: this is beyond what we've covered in the slides

## extract quotes' texts ----

html_elements(page, ".text") %>% html_text()

## extract links to authors' pages ----

html_elements(page, ".author+a") %>% html_attr("href")

# Scrape quotes and authors ----

## create data frame ----

quotes <- html_elements(page, ".text") %>% html_text()
authors <- html_elements(page, ".author") %>% html_text()

data.frame(author_name = authors, quote = quotes)

## define function ----

extract_quotes <- function(page) {
  
  quotes <- html_elements(page, ".text") %>% html_text()
  authors <- html_elements(page, ".author") %>% html_text()
  
  out <- data.frame(author_name = authors, quote = quotes)
  
  return(out)
}

# test
extract_quotes(read_html(url))

## adapt the function ----

extract_quotes <- function(page) {
  quotes <- html_elements(page, ".text") %>% html_text()
  authors <- html_elements(page, ".author") %>% html_text()
  tags <- html_elements(page, ".quote .keywords") %>% html_attr("content")
  
  out <- data.frame(author_name = authors, quote = quotes, tags = tags)
  
  return(out)
}

# test
extract_quotes(read_html(url))

# Scrape all quotes ----

#' TASK: get the text of all quotes on all pages

# we define a number of helper function:
#  1. a function that takes a page URL as an input and returns the 'htlm_documnt' 
#     representation of its parsed HTML code
#  2. 

#' Extract quotes' text from page on quotes.toscrape.com
#'
#' @param page an rvest 'html_document' object
#'
#' @return a character vector of quotes' texts
extract_quotes <- function(page) {
  quotes <- html_elements(page, css = "div.quote > .text")
  quotes_text <- html_text(quotes)
  return(quotes_text)
}

#' Extract the link to the next page on quotes.toscrape.com
#'
#' @param page an rvest 'html_document' object
#'
#' @return  a character value representing the (relative) link to the next page. `NA` if non-existent.
get_next_page_link <- function(page) {
  # locate list item element with class 'next' and extract the anchor element it nests
  el <- html_element(page, "ul.pager > li.next > a")
  # extract the (relative) link
  rel_link <- html_attr(el, "href")
  return(rel_link)
}

# Bring everything together

base_url <- "https://quotes.toscrape.com"

quotes <- list()
page_nr <- 1

repeat {
  message("page ", page_nr)
  
  # construct the URL
  if (page_nr == 1) {
    url <- base_url
  } else {
    url <- paste0(base_url, nxt_page_link)
  }
  
  # parse the page
  page <- read_html(url)
  
  # extract quotes and append to list
  quotes[[page_nr]] <- extract_quotes(page)
  
  # get relative link to next page
  nxt_page_link <- get_next_page_link(page)
  
  # stop if no next page
  if (is.na(nxt_page_link))
    break
  
  # else ...
  # ... increment page counter, ...
  page_nr <- page_nr + 1
  # ... pause, ... 
  Sys.sleep(1)
  
  # ... and then continue
}

# inspect
str(quotes, 1)

# finally: combine all 
quotes <- unlist(quotes)

# check that the first values are the first quotes on the first page
head(quotes)
# check that the last values are the last quotes on the last page
tail(quotes)


# Scrape all quotes data ----

#' TASK: get the text, author name, and tags associated with a quote for all pages  

#' Extract quote data from page on quotes.toscrape.com
#'
#' @param web.element a 'div' web element with class 'quote' from quotes.toscrape.com
#'
#' @return a data frame with columns 'text' (chr), 'author' (chr), and 'tags' (chr)
extract_quote_data <- function(web.element) {
  
  quote_text <- html_text(html_element(web.element, ".text"))
  quote_author <- html_text(html_element(web.element, ".author"))
  quote_tags <- html_attr(html_element(web.element, ".tags > meta.keywords"), "content")
  
  out <- data.frame(
    text = quote_text,
    author = quote_author,
    tags = quote_tags
  )
  
  return(out)
}

#' Extract data of all quotes on a page of quotes.toscrape.com
#'
#' @param page an rvest 'html_document' object
#'
#' @return a data frame with columns 'text' (chr), 'author' (chr), and 'tags' (chr)
extract_quotes_data <- function(page) {
  quotes <- html_elements(page, css = "div.quote")
  out <- purrr::map_dfr(quotes, extract_quote_data) # see ?purrr::map_dfr
  # alternatively: `out <- lapply(quotes, extract_quote_data); do.call("rbind", out)`
  return(out)
}

# Bring everything together

base_url <- "https://quotes.toscrape.com"

# create an empty list
# note: it will contain the data frame with quotes' data from individual pages
quotes <- list()

page_nr <- 1

repeat {
  
  # construct the URL
  if (page_nr == 1) 
    nxt_page_link <- paste0("/page/", page_nr, "/")
  url <- paste0(base_url, nxt_page_link)
  
  message("\b\r", "page ", page_nr)
  
  # parse the page
  page <- read_html(url)
  
  # extract quotes data and append to list
  quotes[[page_nr]] <- extract_quotes_data(page)
  
  # get relative link to next page
  nxt_page_link <- get_next_page_link(page)
  
  # stop if no next page
  if (is.na(nxt_page_link))
    break
  
  # else ...
  # ... increment page counter, ...
  page_nr <- page_nr + 1
  # ... pause, ... 
  Sys.sleep(1.5)
  
  # ... and then continue
}

quotes <- bind_rows(quotes) # <== bind list of data frames along rows

head(quotes)
tail(quotes)

# Exercise 2 ----

# we go for Joe Biden
base_url <- "https://www.presidency.ucsb.edu/advanced-search?field-keywords=&field-keywords2=&field-keywords3=&from%5Bdate%5D=&to%5Bdate%5D=&person2=200320&items_per_page=25"
page <- read_html(base_url)
  
# Exercise 2: decide how to iterate ----

# To iterate over result pages, we adopt solution 3 discussed in the lecture:
# 1. scrape the link underlying the last page pagination button
# 2. parse the page number of the last page from this link
# 3. iterate over all pages from the first to the last

# Hence, we first locate the "last page" button on the first page we , ...
last_page_el <- html_element(page, "ul.pagination > li.pager-last > a")

# ... extract the relative link, ...
last_page_rel_link <- html_attr(last_page_el, "href")

# ... and parse the page number from the URL
last_page_nr <- as.integer(sub(".+&page=(\\d+).*", "\\1", last_page_rel_link))

# Next, we can define the code to scrape the (relative) links to individual speeches from each link
scrape_speech_links <- function(page) {
  html_attr(html_elements(page, ".views-field-title > a"), "href")
}

# Exercise 2: collect speech links ----

# Now, we can iterate over pages until we have collected (at least) 200 links
speech_links <- list()

# note: the total numbers of pages is super high, so we set it to a small value (just to illustrate that the code works)
last_page_nr <- 10

for (page_nr in 1:last_page_nr) {
  
  url <- paste0(base_url, "&page=", page_nr)
  
  message("\b\r", "page ", page_nr)
  
  page <- read_html(url)
  
  speech_links[[page_nr]] <- scrape_speech_links(page)
  
  # pause
  Sys.sleep(1.5)
}

speech_links <- unlist(speech_links)
speech_links

# Exercise 2: collect the speech data ----

#' Scrape a president's speech data
#'
#' @param url 
#'
#' @return a data frame with columns 
#'          'speaker' (chr), 
#'          'speech_date' (date), 
#'          'speech_text' (chr)
scrape_speech_data <- function(url) {
  
  # read and parse the URL
  page <- read_html(url)
  
  speaker <- page %>% 
    # extract the speaker's name
    html_element(".field-docs-person .diet-title") %>% 
    html_text(trim = TRUE)
  
  speech_date <- page %>% 
    # get span element for which attribute 'property' has the value 'dc:date'
    html_element(".field-docs-start-date-time > .date-display-single") %>% 
    # extract the value of its 'content' attribute
    html_attr("content") %>% 
    # convert it to an R 'Date' object
    as.Date()
  
  speech_text <- page %>%
    # get speech content
    html_element(".field-docs-content") %>% 
    # get paragraph elements
    html_elements("p") %>% 
    # extract their text
    html_text() %>% 
    # concatenate into one character value 
    # note: using '\n' as separator allows reconstructing the original paragraph structure
    paste(collapse = "\n")
  
  out <- tibble(speaker, speech_date, speech_text) # <== note: you could use data.frame() instead of tibble()
  
  return(out)
}

# Now iterate over URLs 
base_url <- "https://www.presidency.ucsb.edu"
urls <- paste0(base_url, speech_links)

speeches_data <- list()

# note: run only for first 13 links ()
for (url in urls[1:13]) {
  
  n_ <- length(speeches_data)
  
  speeches_data[[n_+1]] <- scrape_speech_data(url)
  
  message("\b\r", "# speeches scraped = ", n_+1)
  
  Sys.sleep(1.5)
}

# bind list of data frames along rows
bind_rows(speeches_data)
