# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #  
#
#' @title  Advanced API topics: scraping data from hidden APIs
#' @author Allison Koh & Hauke Licht
#' @date   2023-09-22
#' @note   see     
#
# +~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~+~ #

# setup ----

library(httr)

#' EXAMPLE: German postal service location finder
#'    Online app searching for near-by locations given an address.
#'    URL: https://www.deutschepost.de/de/s/standorte.html
#'    
#' Two functions
#'  - find an address: When a user types part of an address in the search field 
#'     (e.g., just a postal code), the App suggests addresses (i.e., auto completion)
#'  - find nearby locations: When a user submits an address, the App displays the
#'     locations of nearby post offices, post boxes, delivery stations etc.
#'     
#' Below, we show how one can emulate the App's interactive behavior by directly
#'  query data from the APIs that operate the App in the background

# function 1: find an address ----

#' @note this is the "AddressFinder" endpoint. It requests possible addresses 
#'   given a user's input in the search field
#'   
#' We have figured this out by observing what changes in the Network tab of 
#'  Chrome's Developer panel (filtering for Fetch/XHR requests). 
#' When you start typing part of an address, the App interactively requests 
#'  potential auto-completion that match your intial input.

endpoint <- "https://www.deutschepost.de/int-postfinder/AddressFinder/rest/select"  

# only one parameter 'combi', which captures users search input
postal_code = "50933"
params <- list("combi" = postal_code)

# important: you need to use a human user-like user agent (without it, you won't get data)
ua <- "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36"

# make the request
resp <- GET(
  endpoint, 
  query = params, 
  accept_json(),
  user_agent(ua) # <== don't forget to add the user agent
)

# parse the results
parsed <- content(resp, as = "parsed")

str(parsed, 1) # <= list of 10 suggested addresses

# let's look at an example
str(parsed[[1]], 1)

# define a function that get's the 'combi', 'lattitude' and 'longitude' values 
#  for a single result
parse_one_result <- function(x) {
  out <- data.frame(
    combi = x$combi,
    latitude = x$latitude,
    longitude = x$longitude
  )
  # note: could also just do `out <- as.data.frame(x[c("combi", "latitude", "longitude")])`
  return(out)
}

# test  
parse_one_result(parsed[[1]])

# iterate over all results (see https://purrr.tidyverse.org/articles/base.html#map-functions)
purrr::map_dfr(parsed, parse_one_result)


# Function 2: get locations of close-by postal service facilities ----

#' @note: When you have entered a postal code or address in the search field 
#'   and hit enter to submit your search request, the online App sends 
#'   a GET request to the 'nearbySearch' endpoint.
#'   
#' We have figured this out by observing what changes in the Network tab of 
#'  Chrome's Developer panel (filtering for Fetch/XHR requests). 
#' When you enter an address, the App interactively requests the data for nearby
#'  service locations.

#' here is how the complete URL of the request looks like (check the 'Header' tab)
#'  with 'address' set to "50933" (just a German postal code)
"https://www.deutschepost.de/int-postfinder/webservice/rest/v1/nearbySearch?address=50933&locationType=PACKSTATION&locationType=POSTSTATION&locationType=RETAIL_OUTLET&locationType=POSTBANK_FINANCE_CENTER&locationType=PAKETSHOP&locationType=LETTER_BOX"

#' let's break this down:
#'  The endpoint (everything before the "?"), is "https://www.deutschepost.de/int-postfinder/webservice/rest/v1/nearbySearch"
#'  Everything after the "?" are API parameter-value pairs.
#'  These parameter-value pairs are separated with the "&" symbol in the URL
params_string <- "address=50933&locationType=PACKSTATION&locationType=POSTSTATION&locationType=RETAIL_OUTLET&locationType=POSTBANK_FINANCE_CENTER&locationType=PAKETSHOP&locationType=LETTER_BOX"
strsplit(params_string, "&")
#' this shows that there are multiple parameters.
#' The one that specified the address for which we request near-by locations
#'  is called "address"

#' Hence, we can _reconstruct_ this request with basic `httr` code

# first define the endpoint
endpoint <- "https://www.deutschepost.de/int-postfinder/webservice/rest/v1/nearbySearch"

# next, define the request parameters
params <- list(
  "address" = "50933",
  # My best guess is that setting the parameters below, you just indicate that
  #   you want to include these "location types" in the list of close-by locations
  "locationType" = "PACKSTATION",
  "locationType" = "POSTSTATION",
  "locationType" = "RETAIL_OUTLET",
  "locationType" = "POSTBANK_FINANCE_CENTER",
  "locationType" = "PAKETSHOP",
  "locationType" = "LETTER_BOX"
)

# make the request
resp <- GET(
  endpoint, 
  query = params, 
  accept_json(),
  user_agent(ua)
)

# check the status code of the response
resp$status_code # looks good!!

# parse the response
parsed <- content(resp, as = "parsed")

# inspect it
str(parsed, 1)
str(parsed$pfLocations, 1) # wow, 250 results!!

# let's look at one result
str(parsed$pfLocations[[1]], 1)
str(parsed$pfLocations[[1]]$geoPosition, 1) # <== geo location info

# define a function that gets values of fields 'locationType', 'zipCode', 
#  'street', 'houseNo', and info from within 'geoPosition'
parse_one_result <- function(x) {
  out <- data.frame(
    locationType = x$locationType,
    zipCode = x$zipCode,
    street = x$street,
    houseNo = x$houseNo,
    latitude = x$geoPosition$latitude,
    longitude = x$geoPosition$longitude
  )
  return(out)
}

# test
parse_one_result(parsed$pfLocations[[1]])

# iterate over all results (see https://purrr.tidyverse.org/articles/base.html#map-functions)
purrr::map_dfr(parsed$pfLocations, parse_one_result)
